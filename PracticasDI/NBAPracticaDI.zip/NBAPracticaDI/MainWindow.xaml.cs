﻿using NBAPracticaDI.Views;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NBAPracticaDI
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        Controller controller;
        public MainWindow()
        {
            InitializeComponent();

            controller = new Controller();

            this.ShowTeams();
        }





        /*
         *  MOSTRAR DATOS  MOSTRAR DATOS  MOSTRAR DATOS  MOSTRAR DATOS  MOSTRAR DATOS  MOSTRAR DATOS  MOSTRAR DATOS
         */

        private void ShowTeams()
        {
            try
            {
                DataTable equiposTabla = controller.getTeams();

                if (equiposTabla == null || equiposTabla.Rows.Count == 0)
                {
                    MessageBox.Show("No hay equipos disponibles.");
                    return;
                }

                lbEquipos.ItemsSource = equiposTabla.DefaultView;
                lbEquipos.DisplayMemberPath = "name";
                lbEquipos.SelectedValuePath = "id";


                if (lbEquipos.Items.Count > 0)
                {
                    lbEquipos.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los equipos");
            }
        }




        private void showPlayersByTeam(string nombreEquipo)
        {
            DataTable playersTabla = controller.getPlayersByTeam(nombreEquipo);

            if (playersTabla is null || playersTabla.Rows.Count == 0)
            {
                MessageBox.Show("Error al cargar los jugadores");

            }
            else
            {
                lbPlayers.ItemsSource = playersTabla.DefaultView;
                lbPlayers.DisplayMemberPath = "DatosJugador";
                lbPlayers.SelectedValuePath = "jugador";

                if (lbPlayers.Items.Count > 0)
                {
                    lbPlayers.SelectedIndex = 0;
                }
            }
        }







        public void showPlayerDetails(string playerName)
        {
            DataTable playerDetails = controller.getPlayerDetails(playerName);

            if (playerDetails.Rows.Count > 0)
            {
                DataRow player = playerDetails.Rows[0];

                JugadorNombre.Content = $"{player["firstName"]} {player["lastName"]}";
                JugadorPosicion.Content = $"Posición: {player["position"]}";
                JugadorAltura.Content = $"Altura: {player["height"]} cm";
                JugadorPeso.Content = $"Peso: {player["weight"]} kg";
                JugadorEdad.Content = $"Edad: {player["age"]}";
                JugadorEquipo.Content = $"Equipo: {player["team"]}";
                JugadorCamiseta.Content = $"Camiseta: #{player["jerseyNumber"]}";
                JugadorAño.Content = $"Año: {player["dateOfBirth"]}";

                // Cargar imagen del jugador
                string imageUrl = player["headShotUrl"].ToString();
                imgPlayerDet.Source = new BitmapImage(new Uri(imageUrl));
            }
            else
            {
                MessageBox.Show("No se encontraron datos para este jugador.");
            }
            
        }



        private void showStatsPlayer(string teamName)
        {
            DataTable stats = controller.GetStatsByTeam(teamName);
            if (stats.Rows.Count > 0)
            {
                DataRow player = stats.Rows[0];
                JugadorNombre.Content = $"{player["firstName"]} {player["lastName"]}";
                JugadorPosicion.Content = $"Posición: {player["position"]}";
                JugadorAltura.Content = $"Altura: {player["height"]} cm";
                JugadorPeso.Content = $"Peso: {player["weight"]} kg";
                JugadorEdad.Content = $"Edad: {player["age"]}";
                JugadorEquipo.Content = $"Equipo: {player["team"]}";
                JugadorCamiseta.Content = $"Camiseta: #{player["jerseyNumber"]}";
                JugadorAño.Content = $"Año: {player["dateOfBirth"]}";
                // Cargar imagen del jugador
                string imageUrl = player["headShotUrl"].ToString();
                imgPlayerDet.Source = new BitmapImage(new Uri(imageUrl));
            }
            else
            {
                MessageBox.Show("No se encontraron datos para este jugador.");
            }
        }










        private void lbEquipos_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lbEquipos.SelectedItem != null || Convert.ToInt32(lbEquipos.SelectedItem) != -1)
            {
                DataRowView equipoSeleccionado = lbEquipos.SelectedItem as DataRowView;

                if (equipoSeleccionado != null)
                {
                    string logo = equipoSeleccionado["teamLogoUrl"]?.ToString();
                    imgEquipo.Source = new BitmapImage(new Uri(logo));

                    showPlayersByTeam(equipoSeleccionado["name"].ToString());
                }
            }
        }




        private void lbPlayers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lbPlayers.SelectedItem != null)
            {
                DataRowView playerSeleccionado = lbPlayers.SelectedItem as DataRowView;

                if (playerSeleccionado != null)
                {
                    string logo = playerSeleccionado["headShotUrl"].ToString();
                    if (logo != "")
                    {
                        imgPlayer.Source = new BitmapImage(new Uri(logo));
                        showPlayerDetails(playerSeleccionado["firstName"].ToString() + " " + playerSeleccionado["lastName"].ToString());

                    }



                }
            }
        }




        /*
         * BOTONES DE ACTUALIZAR BOTONES DE ACTUALIZAR BOTONES DE ACTUALIZAR BOTONES DE ACTUALIZAR BOTONES DE ACTUALIZAR
         */



        private void ActualizarEquipo_Click(object sender, RoutedEventArgs e)
        {
            if (lbEquipos.SelectedValue is null)
            {
                MessageBox.Show("Debes seleccionar el equipo a actualizar antes de pulsar el botón.");
            }
            else
            {
                DataTable team = controller.getTeam(lbEquipos.SelectedValue.ToString());

                if (team != null)
                {
                    UpdateTeam updateTeam = new UpdateTeam(controller, team);

                    updateTeam.ShowDialog();
                    this.ShowTeams();
                }
                else
                {
                    MessageBox.Show("Ha sucedido un error en la carga del equipo.");
                }

            }

        }



        private void ActualizarJugador_Click(object sender, RoutedEventArgs e)
        {
            if (lbPlayers.SelectedItem is DataRowView playerSeleccionado)
            {
                string playerId = playerSeleccionado["id"].ToString();
                string nombreEquipo = playerSeleccionado["team"].ToString();

                DataTable player = controller.getPlayerById(playerId);

                if (player != null && player.Rows.Count > 0)
                {
                    UpdatePlayer updatePlayer = new UpdatePlayer(controller, player);
                    updatePlayer.ShowDialog();
                    this.showPlayersByTeam(nombreEquipo);
                }
                else
                {
                    MessageBox.Show("Ha sucedido un error en la carga del equipo.");
                }
            }
            else
            {
                MessageBox.Show("Debes seleccionar el jugador a actualizar antes de pulsar el botón.");
            }
        }






        private void ActualizarEstadistica_Click(object sender, RoutedEventArgs e)
        {
            if (lbPlayers.SelectedItem is DataRowView playerSeleccionado)
            {
                string playerId = playerSeleccionado["id"].ToString();

                DataTable player = controller.getPlayerById(playerId);

                if (player != null && player.Rows.Count > 0)
                {
                    UpdatePlayer updatePlayer = new UpdatePlayer(controller, player);
                    updatePlayer.ShowDialog();
                    this.showPlayersByTeam(playerId);
                    this.showPlayerDetails(playerId);
                }
                else
                {
                    MessageBox.Show("Ha sucedido un error en la carga del equipo.");
                }
            }
            else
            {
                MessageBox.Show("Debes seleccionar el jugador a actualizar antes de pulsar el botón.");
            }
        }





        /*
         * BOTONES DE ELIMINAR BOTONES DE ELIMINAR BOTONES DE ELIMINAR BOTONES DE ELIMINAR BOTONES DE ELIMINAR BOTONES DE ELIMINAR
         */



        private void EliminarJugador_Click(object sender, RoutedEventArgs e)
        {

            if (lbPlayers.SelectedItem is DataRowView playerSeleccionado)
            {
                string playerId = playerSeleccionado["id"].ToString();

                MessageBoxResult resultado = MessageBox.Show(
                    "¿Estás seguro de que deseas eliminar este jugador?",
                    "Confirmar eliminación",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (resultado == MessageBoxResult.Yes)
                {
                    bool exito = controller.deletePlayer(playerId);

                    if (exito)
                    {
                        MessageBox.Show("Jugador eliminado correctamente.");
                        this.showPlayersByTeam(playerId);
                        string teamname = playerSeleccionado["team"].ToString();
                        this.showPlayersByTeam(teamname);

                    }
                    else
                    {
                        MessageBox.Show("Error al eliminar el jugador o ya no existe.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Debes seleccionar un jugador antes de eliminar.");
            }
        }

        private void EliminarJugadorDet_Click(object sender, RoutedEventArgs e)
        {
            if (lbPlayers.SelectedItem is DataRowView playerSeleccionado)
            {
                string playerId = playerSeleccionado["id"].ToString();

                MessageBoxResult resultado = MessageBox.Show(
                    "¿Estás seguro de que deseas eliminar este jugador?",
                    "Confirmar eliminación",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (resultado == MessageBoxResult.Yes)
                {
                    bool exito = controller.deletePlayer(playerId);

                    if (exito)
                    {
                        MessageBox.Show("Jugador eliminado correctamente.");
                        this.showPlayersByTeam(playerId);
                    }
                    else
                    {
                        MessageBox.Show("Error al eliminar el jugador o ya no existe.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Debes seleccionar un jugador antes de eliminar.");
            }

        }






        /*
         * BOTONES DE INSERTAR BOTONES DE INSERTAR BOTONES DE INSERTAR BOTONES DE INSERTAR BOTONES DE INSERTAR BOTONES DE INSERTAR
         */
        internal void InsertarEquipo()
        {
            InsertTeam ventanaInsertar = new InsertTeam();
            ventanaInsertar.ShowDialog();
            this.ShowTeams();
        }
        private void InsertarEquipo_Click   (object sender, RoutedEventArgs e)
        {
            this.InsertarEquipo();
        }

        internal void InsertarJugador()
        {
            if (lbEquipos.SelectedItem is DataRowView equipoSeleccionado)
            {
                string teamName = equipoSeleccionado["name"].ToString();
                InsertPlayer ventanaInsertar = new InsertPlayer(teamName);
                ventanaInsertar.ShowDialog();
                this.showPlayersByTeam(teamName);


            }
            else
            {
                MessageBox.Show("Seleccione un equipo antes de añadir un jugador.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }



        private void InsertarJugador_Click(object sender, RoutedEventArgs e)
        {
            this.InsertarJugador();

        }





        private void InsertarJugadorDet_Click(object sender, RoutedEventArgs e)
        {
            this.InsertarJugador();
        }



        /*
         * MÉTODOS PARA EL MENÚ
         */

        private void SalirItem_Click(object sender, RoutedEventArgs e)
        {
            this.Close();

        }


        //EXAMEN3

       internal void Buscar()
        {
            BuscarJugador ventanaBuscar = new BuscarJugador(controller);
            ventanaBuscar.ShowDialog();
        }
        private void Buscar(object sender, RoutedEventArgs e)
        {
            this.Buscar();

        }

        private void BuscarJugador_Click(object sender, RoutedEventArgs e)
        {
            this.Buscar();
        }


        private void AcercaDe_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Aplicación desarrollada por: Noemi Dinicu Vararu\nEsta aplicación " +
                "es una practica de Diseño de Interfaces dónde ponemos en practica" +
                "nuestros conocimientos de WPF y C#");
        }

        private void MenuAyuda_Click(object sender, RoutedEventArgs e)
        {


        }

        private void MenuAcercaDe_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Aplicación desarrollada por: Noemi Dinicu Vararu\nEsta aplicación " +
               "es una practica de Diseño de Interfaces dónde ponemos en practica" +
               "nuestros conocimientos de WPF y C#");

        }

        private void Salir(object sender, RoutedEventArgs e)
        {
            // Cierra la ventana principal y finaliza la aplicación
            this.Close();
        }

        private void ToolbarButton_Click(object sender, RoutedEventArgs e)
        {
            // Determinar qué control activó el evento (puede ser un Button o un MenuItem)
            string action = "";

            // Si el evento fue activado por un botón de la Toolbar
            if (sender is Button clickedButton)
            {
                if (clickedButton == btnInsert) action = "Insert"; // Botón para insertar
                else if (clickedButton == btnDelete) action = "Delete"; // Botón para eliminar
                else if (clickedButton == btnActualizar) action = "Update"; // Botón para actualizar
                else if (clickedButton == btnImprimir) action = "Imprimir"; // Botón para imprimir
                else if (clickedButton == btnBuscar) action = "Buscar"; // Botón para buscar Examen3
            }
            // Si el evento fue activado por un menú del Menú Principal
            else if (sender is MenuItem clickedMenuItem)
            {
                // Se verifica el texto del menú para determinar la acción
                if (clickedMenuItem.Header.ToString().Contains("Nuevo")) action = "Insert";
                else if (clickedMenuItem.Header.ToString().Contains("Eliminar")) action = "Delete";
                else if (clickedMenuItem.Header.ToString().Contains("Actualizar")) action = "Update";
                else if (clickedMenuItem.Header.ToString().Contains("Imprimir")) action = "Imprimir"; // EXAMEN1
                else if (clickedMenuItem.Header.ToString().Contains("Buscar")) action = "Buscar"; // EXAMEN3
            }

            // Si no se detectó ninguna acción válida, se sale del método
            if (string.IsNullOrEmpty(action)) return;

            // Obtener la pestaña actualmente seleccionada en el TabControl
            TabItem selectedTab = TabControl.SelectedItem as TabItem;
            if (selectedTab == null) return;

            // Obtener el nombre de la pestaña activa
            string header = selectedTab.Header.ToString();

            // Ejecutar la acción correspondiente dependiendo de la pestaña activa
            switch (action)
            {
                case "Insert":
                    if (header == "Equipos")
                    {
                        // No se permite insertar equipos, muestra un mensaje
                        MessageBox.Show("No se puede insertar un Equipo");
                    }
                    else if (header == "Plantilla")
                    {
                        // Llama al método para insertar un jugador en la plantilla
                        InsertarJugador_Click(sender, e);
                    }
                    else if (header == "Jugador")
                    {
                        // Llama al método para insertar un jugador en la pestaña de jugadores
                        InsertarJugadorDet_Click(sender, e);
                    }
                    break;

                case "Delete":
                    if (header == "Equipos")
                    {
                        // No se permite eliminar equipos, muestra un mensaje
                        MessageBox.Show("No se puede eliminar un Equipo");
                    }
                    else if (header == "Plantilla" || header == "Jugador")
                    {
                        // Llama al método para eliminar un jugador
                        EliminarJugador_Click(sender, e);
                    }
                    break;

                case "Update":
                    if (header == "Equipos")
                    {
                        // Llama al método para actualizar información de un equipo
                        ActualizarEquipo_Click(sender, e);
                    }
                    else if (header == "Plantilla")
                    {
                        // Llama al método para actualizar información de un jugador en la plantilla
                        ActualizarJugador_Click(sender, e);
                    }
                    else if (header == "Jugador")
                    {
                        // Llama al método para actualizar información de un jugador individual
                        ActualizarJugador_Click(sender, e);
                    }
                    break;
                case "Imprimir":
                    // Llama al método para imprimir la ventana actual EXAMEN1
                    bImprimir_Click(sender, e);
                    break;
                case "Buscar":
                    // Llama al método para buscar un jugador EXAMEN3
                    BuscarJugador_Click(sender, e);
                    break;
            }
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            // Obtiene la pestaña seleccionada
            var selectedTab = (TabItem)TabControl.SelectedItem;
            string header = selectedTab.Header.ToString();

            if (Keyboard.Modifiers == ModifierKeys.Control)
            {

                // Salir de la aplicación con Ctrl + Q
                if (e.Key == Key.Q)
                {
                    MessageBox.Show("Saliendo de la aplicación");
                    this.Close();
                }

                // Abrir la ventana de ayuda con Ctrl + A
                if (e.Key == Key.A)
                {
                    MenuAyuda_Click(sender, e);
                }

                // Abrir la ventana "Acerca de" con Ctrl + T
                if (e.Key == Key.T)
                {
                    MenuAcercaDe_Click(sender, e);
                }

                // Acciones específicas para la pestaña "Equipos"
                if (header == "Equipos")
                {
                    // Abrir ventana de actualización con Ctrl + U
                    if (e.Key == Key.U)
                    {
                        ActualizarEquipo_Click(sender, e);
                    }
                    // Imprimir ventana con Ctrl + P EXAMEN1
                    if (e.Key == Key.P)
                    {
                        bImprimir_Click(sender, e);
                    }
                    if (e.Key == Key.B) //Examen3
                    {
                        BuscarJugador_Click(sender, e);
                    }
                }

                // Acciones específicas para la pestaña "Plantilla"
                if (header == "Plantilla")
                {
                    // Insertar jugador con Ctrl + I
                    if (e.Key == Key.I)
                    {
                        ActualizarJugador_Click(sender, e);
                    }

                    // Eliminar jugador con Ctrl + D
                    if (e.Key == Key.D)
                    {
                        EliminarJugador_Click(sender, e);
                    }

                    // Actualizar jugador con Ctrl + U
                    if (e.Key == Key.U)
                    {
                        ActualizarJugador_Click(sender, e);
                    }
                    // Imprimir ventana con Ctrl + P 
                    if (e.Key == Key.P)
                    {
                        bImprimir_Click(sender, e);
                    }

                    if (e.Key == Key.B) //Examen3
                    {
                        BuscarJugador_Click(sender, e);
                    }
                }

                // Acciones específicas para la pestaña "Jugador"
                if (header == "Jugador")
                {
                    // Insertar jugador con Ctrl + I
                    if (e.Key == Key.I)
                    {
                        InsertarJugador_Click(sender, e);
                    }

                    // Eliminar jugador con Ctrl + D
                    if (e.Key == Key.D)
                    {
                        EliminarJugador_Click(sender, e);
                    }

                    // Actualizar jugador con Ctrl + U
                    if (e.Key == Key.U)
                    {
                        ActualizarJugador_Click(sender, e);
                    }
                    // Imprimir ventana con Ctrl + P
                    if (e.Key == Key.P)
                    {
                        bImprimir_Click(sender, e);
                    }
                    if (e.Key == Key.B) //Examen3
                    {
                        BuscarJugador_Click(sender, e);
                    }
                }

            }
        }


        // Evento del botón "Imprimir" Examen1
        private void bImprimir_Click(object sender, RoutedEventArgs e)
        {
           this.Imprimir();
        }
        private void Imprimir(object sender, RoutedEventArgs e)
        {
           this.Imprimir();

        }

        internal void Imprimir()
        {
            WPreliminar vistaPreliminar = new WPreliminar(visualPlantilla);
            vistaPreliminar.ShowDialog();

        }

       


    }
}