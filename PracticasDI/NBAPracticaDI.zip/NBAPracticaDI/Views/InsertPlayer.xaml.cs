﻿using System;
using System.Data;
using System.Windows;

namespace NBAPracticaDI.Views
{
    /// <summary>
    /// Lógica de interacción para InsertPlayer.xaml
    /// </summary>
    public partial class InsertPlayer : Window
    {
        Controller controller;

        public InsertPlayer(string teamName)
        {
            InitializeComponent();
            controller = new Controller();

            // Establecer el equipo en el campo correspondiente
            this.tbEquipo.Text = teamName;

        }

        public InsertPlayer(Controller controller, DataTable player)
        {
            this.controller = controller;

            DataColumnCollection players = player.Columns;

            InitializeComponent();

            this.tbIdJugador.Text = player.Rows[0][players[0].ColumnName].ToString();
            this.tbNombre.Text = player.Rows[0][players[1].ColumnName].ToString();
            this.tbApellidos.Text = player.Rows[0][players[2].ColumnName].ToString();
            this.tbEquipo.Text = player.Rows[0][players[3].ColumnName].ToString();
            this.tbPosicion.Text = player.Rows[0][players[4].ColumnName].ToString();
            this.tbFecha.Text = player.Rows[0][players[5].ColumnName].ToString();
            this.tbAltura.Text = player.Rows[0][players[6].ColumnName].ToString();
            this.tbPeso.Text = player.Rows[0][players[7].ColumnName].ToString();
            this.tbCamiseta.Text = player.Rows[0][players[8].ColumnName].ToString();
            this.tbEdad.Text = player.Rows[0][players[9].ColumnName].ToString();
        }

        private void bCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void InsertarJugador_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidarDatosJugador())
            {
                return;
            }
            MessageBox.Show("Se va aproceder a la inserción de datos del Jugador.");

            string[] player = new string[9];
            player[0] = tbNombre.Text;
            player[1] = tbApellidos.Text;
            player[2] = tbEquipo.Text;
            player[3] = tbPosicion.Text;
            player[4] = tbFecha.Text;
            player[5] = tbAltura.Text;
            player[6] = tbPeso.Text;
            player[7] = tbCamiseta.Text;
            player[8] = tbEdad.Text;
            bool resultado = controller.insertPlayer(player);

            if (!resultado )
            {
                MessageBox.Show("Ha sucedido un error al insertar y no se ha podido realizar.\n" +
                    "La excepción es: " + resultado);
                this.Close();
            }
            else
            {
                MessageBox.Show("La inserción se ha realizado correctamente.");
                this.Close();
            }

        }



        private bool ValidarDatosJugador()
        {
            // Verificar que los campos de texto no estén vacíos
            if (string.IsNullOrWhiteSpace(tbNombre.Text))
            {
                MessageBox.Show("El nombre del jugador no puede estar vacío.");
                return false;
            }

            if (string.IsNullOrWhiteSpace(tbApellidos.Text))
            {
                MessageBox.Show("Los apellidos del jugador no pueden estar vacíos.");
                return false;
            }

            if (string.IsNullOrWhiteSpace(tbEquipo.Text))
            {
                MessageBox.Show("El equipo no puede estar vacío.");
                return false;
            }

            if (string.IsNullOrWhiteSpace(tbPosicion.Text))
            {
                MessageBox.Show("La posición no puede estar vacía.");
                return false;
            }

            // Validar que la fecha sea válida
            if (!DateTime.TryParse(tbFecha.Text, out _))
            {
                MessageBox.Show("La fecha ingresada no es válida.");
                return false;
            }

            // Validar que la altura sea un número positivo
            if (!double.TryParse(tbAltura.Text, out double altura) || altura <= 0 || altura > 3)
            {
                MessageBox.Show("La altura debe ser un número positivo y lógico (por ejemplo, entre 0 y 3 metros).");
                return false;
            }

            // Validar que el peso sea un número positivo
            if (!double.TryParse(tbPeso.Text, out double peso) || peso <= 0 || peso > 200)
            {
                MessageBox.Show("El peso debe ser un número positivo y lógico (por ejemplo, entre 0 y 200 kg).");
                return false;
            }

            // Validar que la camiseta sea un número entero positivo
            if (!int.TryParse(tbCamiseta.Text, out int camiseta) || camiseta <= 0)
            {
                MessageBox.Show("El número de camiseta debe ser un número entero positivo.");
                return false;
            }

            // Validar que la edad sea un número entero positivo dentro de un rango lógico
            if (!int.TryParse(tbEdad.Text, out int edad) || edad <= 0 || edad > 100)
            {
                MessageBox.Show("La edad debe ser un número entero positivo y lógico (por ejemplo, entre 0 y 100 años).");
                return false;
            }

            return true;
        }


    }
}