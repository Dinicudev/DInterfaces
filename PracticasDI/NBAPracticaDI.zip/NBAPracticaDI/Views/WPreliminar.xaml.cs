﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Printing;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAPracticaDI.Views
{
    /// <summary>
    /// Lógica de interacción para WPreliminar.xaml
    /// </summary>
    public partial class WPreliminar : Window
    {
        //Examen1
        private Grid visualPlantilla;
        public WPreliminar(Grid visualPlantilla)
        {
            InitializeComponent();
            this.visualPlantilla = visualPlantilla;


            FixedDocument fixedDoc = new FixedDocument();

            PageContent pageContent = new PageContent();
            FixedPage fixedpage = new FixedPage();

            var visualBrush = new VisualBrush(visualPlantilla);

            var rectangle = new Rectangle
            {
                Width = visualPlantilla.ActualWidth,
                Height = visualPlantilla.ActualHeight,
                Fill = visualBrush
            };
            fixedpage.Children.Add(rectangle);
            ((IAddChild)pageContent).AddChild(fixedpage);
            pageContent.Width = visualPlantilla.Width;
            pageContent.Height = visualPlantilla.Height;

            fixedDoc.Pages.Add(pageContent);

            this.vistaPreliminar.Document = fixedDoc;
        }

        private void bImprimir_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();

            printDialog.PrintQueue = new PrintQueue(new PrintServer(), "Microsoft Print to PDF");
            printDialog.PrintTicket.PageMediaSize = new PageMediaSize(visualPlantilla.ActualWidth, visualPlantilla.ActualHeight);
            printDialog.PrintTicket.PageOrientation = PageOrientation.Landscape;

            printDialog.PrintVisual(visualPlantilla, "Grid a PDF");

        }
    }
}
