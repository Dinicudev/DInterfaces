﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAPracticaDI.Views
{
    /// <summary>
    /// Lógica de interacción para UpdateTeam.xaml
    /// </summary>
    public partial class UpdateTeam : Window
    {
        Controller controller;
        DataTable teamTable;

        public UpdateTeam(Controller controller, DataTable teamTable)
        {
            this.controller = controller;
            this.teamTable = teamTable;

            InitializeComponent();



            DataColumnCollection columns = teamTable.Columns;
            this.tbIdEquipo.Text = teamTable.Rows[0][columns[0].ColumnName].ToString();
            this.tbNombre.Text = teamTable.Rows[0][columns[1].ColumnName].ToString();

        }   

        public UpdateTeam(Controller controller, int equipoId, DataTable team)
        {
            
            DataColumnCollection columns = team.Columns;

            InitializeComponent();

            this.tbIdEquipo.Text = team.Rows[0][columns[0].ColumnName].ToString();
            this.tbNombre.Text = team.Rows[0][columns[1].ColumnName].ToString();
        }

        private void bCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void bInsertTeam_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Se va aproceder a la actualización de datos del Equipo.");

            string[] team = new string[2];
            team[0] = tbIdEquipo.Text;
            team[1] = tbNombre.Text;

            bool resultado = controller.updateTeam(team);

            if (!resultado)
            {
                MessageBox.Show("Ha sucedido un error en la actualización y no se ha podido realizar.\n" +
                    "La excepción es: " + resultado);
                this.Close();
            }
            else
            {
                MessageBox.Show("La actualización se ha realizado correctamente.");
                this.Close();
            }
        }

    }
}
