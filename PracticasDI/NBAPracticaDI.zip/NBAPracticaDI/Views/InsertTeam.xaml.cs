﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAPracticaDI.Views
{
    /// <summary>
    /// Lógica de interacción para InsertTeam.xaml
    /// </summary>
    public partial class InsertTeam : Window
    {
        Controller controller;
        public InsertTeam()
        {
            InitializeComponent();
            controller = new Controller();

            
        }

        public InsertTeam(Controller controller, DataTable team)
        {
            this.controller = controller;

            DataColumnCollection teams = team.Columns;

            InitializeComponent();

            this.tbIdEquipo.Text = team.Rows[0][teams[0].ColumnName].ToString();
            this.tbNombre.Text = team.Rows[0][teams[1].ColumnName].ToString();
           
        }

        private void bCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void bInsertTeam_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidarDatosJugador())
            {
                return;
            }
            MessageBox.Show("Se va aproceder a la inserción de datos del Jugador.");

            string[] team = new string[1];
            team[0] = tbNombre.Text;
           
            bool resultado = controller.insertTeam(team);

            if (!resultado)
            {
                MessageBox.Show("Ha sucedido un error al insertar y no se ha podido realizar.\n" +
                    "La excepción es: " + resultado);
                this.Close();
            }
            else
            {
                MessageBox.Show("La inserción se ha realizado correctamente.");
                this.Close();
            }

        }
        private bool ValidarDatosJugador()
        {
            // Verificar que los campos de texto no estén vacíos
            if (string.IsNullOrWhiteSpace(tbNombre.Text))
            {
                MessageBox.Show("El nombre del jugador no puede estar vacío.");
                return false;
            }

            return true;
        }
    }
}
