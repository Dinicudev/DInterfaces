﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAPracticaDI.Views
{
    /// <summary>
    /// Lógica de interacción para BuscarJugador.xaml
    /// </summary>
    public partial class BuscarJugador : Window
    {
        Controller controller;

        public BuscarJugador(Controller controller)
        {
            InitializeComponent();
            this.controller = controller;
        }

        private void btnBuscar_Click(object sender, RoutedEventArgs e)
        {
            string apellidoBuscado = txtApellido.Text.Trim();

            if (string.IsNullOrWhiteSpace(apellidoBuscado))
            {
                MessageBox.Show("Ingrese un apellido para buscar.");
                return;
            }

            DataTable jugadoresEncontrados = controller.getJugadorByApellido(apellidoBuscado);

            if (jugadoresEncontrados == null || jugadoresEncontrados.Rows.Count == 0)
            {
                lblMensaje.Text = "Jugador no encontrado.";
                lblMensaje.Visibility = Visibility.Visible;
                dgResultados.Visibility = Visibility.Collapsed;
            }
            else
            {
                dgResultados.ItemsSource = jugadoresEncontrados.DefaultView;
                dgResultados.Visibility = Visibility.Visible;
                lblMensaje.Visibility = Visibility.Collapsed;
            }
        }

        private void dgResultados_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgResultados.SelectedItem is DataRowView rowView)
            {
                string apellidoJugador = rowView["lastName"].ToString();

                MainWindow ventanaPrincipal = (MainWindow)Application.Current.MainWindow;

                ventanaPrincipal.showPlayerDetails(apellidoJugador);

                ventanaPrincipal.TabControl.SelectedItem = ventanaPrincipal.tabJugador;
                ventanaPrincipal.TabControl.Dispatcher.Invoke(() => { }, System.Windows.Threading.DispatcherPriority.Render);

                this.Close();

                
            }
        }




        private void AbrirActualizarJugador(DataTable jugador)
        {
            UpdatePlayer ventanaActualizar = new UpdatePlayer(controller, jugador);
            ventanaActualizar.ShowDialog();
        }
    }
}