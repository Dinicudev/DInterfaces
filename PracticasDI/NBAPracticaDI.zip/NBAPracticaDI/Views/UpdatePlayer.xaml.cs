﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAPracticaDI.Views
{
    /// <summary>
    /// Lógica de interacción para UpdatePlayer.xaml
    /// </summary>
    public partial class UpdatePlayer : Window
    {
        Controller controller;
        DataTable player;

        public UpdatePlayer(Controller controller, DataTable player)
        {
            this.controller = controller;
            this.player = player;

            DataColumnCollection players = player.Columns;

            InitializeComponent();

            this.tbIdJugador.Text = player.Rows[0][players[0].ColumnName].ToString();
            this.tbNombre.Text = player.Rows[0][players[1].ColumnName].ToString();
            this.tbApellidos.Text = player.Rows[0][players[2].ColumnName].ToString();
            this.tbEquipo.Text = player.Rows[0][players[3].ColumnName].ToString();
            this.tbPosicion.Text = player.Rows[0][players[4].ColumnName].ToString();
            this.tbFecha.Text = player.Rows[0][players[5].ColumnName].ToString();
            this.tbAltura.Text = player.Rows[0][players[6].ColumnName].ToString();
            this.tbPeso.Text = player.Rows[0][players[7].ColumnName].ToString();
            this.tbCamiseta.Text = player.Rows[0][players[8].ColumnName].ToString();
            this.tbEdad.Text = player.Rows[0][players[9].ColumnName].ToString();
        }


        private void bCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void bActualizarJugador_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Se va aproceder a la actualización de datos del Jugador.");

            string[] player = new string[10];
            player[0] = tbIdJugador.Text;
            player[1] = tbNombre.Text;
            player[2] = tbApellidos.Text;
            player[3] = tbEquipo.Text;
            player[4] = tbPosicion.Text;
            player[5] = tbFecha.Text;
            player[6] = tbAltura.Text;
            player[7] = tbPeso.Text;
            player[8] = tbCamiseta.Text;
            player[9] = tbEdad.Text;
            bool resultado = controller.updatePlayers(player);

            if (!resultado)
            {
                MessageBox.Show("Ha sucedido un error en la actualización y no se ha podido realizar.\n" +
                    "La excepción es: " );
                this.Close();
            }
            else
            {
                MessageBox.Show("La actualización se ha realizado correctamente.");
                this.Close();
            }

        }
    }
}
