﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NBAPracticaDI
{
    public class Controller
    {

        Model model;


        /*
         *           MÉTODOS GET MÉTODOS GET MÉTODOS GET MÉTODOS GET MÉTODOS GET MÉTODOS GET MÉTODOS GET MÉTODOS GET
         */


        public Controller()
        {
            model = new Model();
        }

        internal DataTable getTeams()
        {
            return model.getTeams();
        }


        internal DataTable getTeam(string idTeam)
        {
            return model.getTeam(idTeam);
        }      


        internal DataTable getPlayersByTeam(string team)
        {
            return model.getPlayersByTeam(team);
        }


        internal DataTable getPlayerById(string playerId)
        {
            return model.getPlayerById(playerId);
        }

        internal DataTable getPlayerDetails(string playerName)
        {
            return model.getPlayerDetails(playerName);
        }

        internal DataTable GetStatsByTeam(string idPlayer)
        {
            return model.GetStatsByTeam(idPlayer);
        }

        internal DataTable getJugadorByApellido(string apellido)
        {
            return model.getJugadorByApellido(apellido);
        }



        /*
        *           MÉTODOS UPDATE  MÉTODOS UPDATE  MÉTODOS UPDATE  MÉTODOS UPDATE  MÉTODOS UPDATE  MÉTODOS UPDATE
        */


        internal bool updateTeam(string[] team)
        {
            return model.updateTeam(team);
        }



        internal bool updatePlayers(string [] player)
        {
            return model.updatePlayers(player);
        }



        internal string updateEstadistica(string[] estadistica)
        {
            return model.updateEstadistica(estadistica);
        }
        
       





        /*
         * MÉTODOS INSERT MÉTODOS INSERT MÉTODOS INSERT MÉTODOS INSERT MÉTODOS INSERT MÉTODOS INSERT MÉTODOS INSERT
         */



        internal bool insertPlayer(string[] playerData)
        {
            return model.insertPlayer(playerData);
        }

        internal bool insertTeam(string[] teamData)
        {
            return model.insertTeam(teamData);
        }


        /*
        * MÉTODOS DELETE MÉTODOS DELETE MÉTODOS DELETE MÉTODOS DELETE MÉTODOS DELETE MÉTODOS DELETE MÉTODOS DELETE
        */



        internal bool deletePlayer(string idPlayer)
        {
            return model.deletePlayer(idPlayer);
        }

       
    }
}
