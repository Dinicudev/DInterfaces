﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace NBAPracticaDI
{
    internal class Model
    {
        SqlConnection miConexionSQL;


        public Model()
        {
            string miConexion = ConfigurationManager.ConnectionStrings["NBAPracticaDI.Properties.Settings.nbadbConnectionString"].ConnectionString;
            miConexionSQL = new SqlConnection(miConexion);
        }



        /*
         *           MÉTODOS GET MÉTODOS GET MÉTODOS GET MÉTODOS GET MÉTODOS GET MÉTODOS GET MÉTODOS GET MÉTODOS GET
         */


        internal DataTable getTeams()
        {
            string consulta = "SELECT * FROM team";

            SqlDataAdapter miAdaptador = new SqlDataAdapter(consulta, miConexionSQL);

            try
            {
                using (miAdaptador)
                {
                    DataTable equiposTabla = new DataTable();
                    miAdaptador.Fill(equiposTabla);
                    return equiposTabla;
                }
            }
            catch (Exception e)
            {
                return null;
            }
        }



        internal DataTable getTeam(string idTeam)
        {
            string consulta = "SELECT * FROM team WHERE id = @idTeam";

            // Crea un adaptador de datos con la consulta y la conexión
            SqlDataAdapter miAdaptador = new SqlDataAdapter(consulta, miConexionSQL);

            try
            {
                using (miAdaptador)
                {
                    miAdaptador.SelectCommand.Parameters.AddWithValue("@idTeam", idTeam);
                                        
                    DataTable equipoTabla = new DataTable();
                                    
                    miAdaptador.Fill(equipoTabla);
                    
                    return equipoTabla;
                }
            }
            catch (Exception e)
            {
                return null;
            }

        }
                       


        internal DataTable getPlayersByTeam(string nombreEquipo)
        {
            string consulta = "SELECT *, CONCAT(position, ' -> ', firstName, ' ', lastName) AS DatosJugador FROM Player WHERE team = @nombreEquipo ORDER BY position, firstName";


            DataTable playersTabla = new DataTable();

            try
            {
                miConexionSQL.Open();
                using (SqlCommand comandoSQL = new SqlCommand(consulta, miConexionSQL))
                {
                    comandoSQL.Parameters.AddWithValue("@nombreEquipo", nombreEquipo);

                    using (SqlDataAdapter miAdaptador = new SqlDataAdapter(comandoSQL))
                    {
                        miAdaptador.Fill(playersTabla);
                    }
                }
            }
            catch (Exception ex)
            {
                
                return null;
            }
            finally
            {
                miConexionSQL.Close();
            }

            

            return playersTabla;
        }


        internal DataTable getPlayerById(string playerId)
        {
            string consulta = "SELECT * FROM player WHERE id = @playerId";

            SqlDataAdapter miAdaptador = new SqlDataAdapter(consulta, miConexionSQL);

            try
            {
                using (miAdaptador)
                {
                    miAdaptador.SelectCommand.Parameters.AddWithValue("@playerId", playerId);

                    DataTable playerTabla = new DataTable();

                    miAdaptador.Fill(playerTabla);

                    return playerTabla;
                }
            }
            catch (Exception e)
            {
                return null;
            }
        }

        public DataTable GetStatsByTeam(string teamName)
        {
            DataTable players = new DataTable();
            string consulta = "SELECT id, firstName, lastName, position, team, headShotUrl, careerPoints, careerRebounds, careerBlocks, careerTurnovers, careerPercentageThree, careerPercentageFreethrow, careerPercentageFieldGoal FROM player WHERE team = @team";
            SqlCommand command = new SqlCommand(consulta, miConexionSQL);
            command.Parameters.AddWithValue("@team", teamName);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            adapter.Fill(players);
            return players;
        }

        internal DataTable getPlayerDetails(string playerName)
        {
            //string consulta = "SELECT firstName, lastName, position, height, weight, age, team, jerseyNumber, dateOfBirth, headShotUrl FROM Player WHERE CONCAT(firstName, ' ', lastName) = @playerName ";
            string consulta = "SELECT * FROM Player WHERE CONCAT(firstName, ' ', lastName) = @playerName ";
            DataTable playerDetail = new DataTable();
            try
            {
                miConexionSQL.Open();
                using (SqlCommand comandoSQL = new SqlCommand(consulta, miConexionSQL))
                {
                    comandoSQL.Parameters.AddWithValue("@playerName", playerName);
                    using (SqlDataAdapter miAdaptador = new SqlDataAdapter(comandoSQL))
                    {
                        miAdaptador.Fill(playerDetail);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al obtener los detalles del jugador: {ex.Message}");
                return null;
            }
            finally
            {
                miConexionSQL.Close();
            }
            return playerDetail;


        }

        //EXAMEN 3
        internal DataTable getJugadorByApellido(string apellido)
        {
            string consulta = "SELECT * FROM player WHERE lastName = @apellido";
            SqlDataAdapter miAdaptador = new SqlDataAdapter(consulta, miConexionSQL);
            try
            {
                using (miAdaptador)
                {
                    miAdaptador.SelectCommand.Parameters.AddWithValue("@apellido", apellido);
                    DataTable jugadorTabla = new DataTable();
                    miAdaptador.Fill(jugadorTabla);
                    return jugadorTabla;
                }
            }
            catch (Exception e)
            {
                return null;
            }
        }








        /*
        *           MÉTODOS UPDATE  MÉTODOS UPDATE  MÉTODOS UPDATE  MÉTODOS UPDATE  MÉTODOS UPDATE  MÉTODOS UPDATE
        */



        internal bool updateTeam(string[] team)
        {
            try
            {
                string consulta = "UPDATE team SET name='" + team[1] + "' WHERE id=" + team[0];

                SqlCommand comando = new SqlCommand(consulta, miConexionSQL);

                miConexionSQL.Open();
                comando.ExecuteNonQuery();
                miConexionSQL.Close();

                return true;
            }
            catch (Exception ex)
            {
                miConexionSQL.Close();
                Console.WriteLine( ex.Message.ToString());
                return false;
                
            }
        }



        internal bool updatePlayers(string[] player)
        {
            string consulta = "UPDATE player SET firstName = @firstName, " +
                   "lastName = @lastName, " +
                   "team = @team, " +
                   "position = @position, " +
                   "dateOfBirth = @dateOfBirth, " +
                   "height = @height, " +
                   "weight = @weight, " +
                   "jerseyNumber = @jerseyNumber, " +
                   "age = @age " +
                   "WHERE id = @id";
            try
            {
                miConexionSQL.Open();
                using (SqlCommand comandoSQL = new SqlCommand(consulta, miConexionSQL))
                {comandoSQL.Parameters.AddWithValue("@id", player[0]);
                comandoSQL.Parameters.AddWithValue("@firstName", player[1]);
                comandoSQL.Parameters.AddWithValue("@lastName", player[2]);
                comandoSQL.Parameters.AddWithValue("@team", player[3]);
                comandoSQL.Parameters.AddWithValue("@position", player[4]);
                comandoSQL.Parameters.AddWithValue("@dateOfBirth", player[5]);
                comandoSQL.Parameters.AddWithValue("@height", player[6]);
                comandoSQL.Parameters.AddWithValue("@weight", player[7]);
                comandoSQL.Parameters.AddWithValue("@jerseyNumber", player[8]);
                comandoSQL.Parameters.AddWithValue("@age", player[9]);

                    int filasAfectadas = comandoSQL.ExecuteNonQuery();

                    MessageBox.Show($"Filas actualizadas: {filasAfectadas}");
                    return filasAfectadas > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar jugador: " + ex.Message);
                return false;
            }
            finally
            {
                miConexionSQL.Close();
            }
        }




        internal string updateEstadistica(string[] estadistica)
        {
            try
            {
                string consulta = "UPDATE player SET position='" + estadistica[1] + "', " +
                    "WHERE id=" + estadistica[0];

                SqlCommand comando = new SqlCommand(consulta, miConexionSQL);

                miConexionSQL.Open();
                comando.ExecuteNonQuery();
                miConexionSQL.Close();

                return null;
            }
            catch (Exception ex)
            {
                miConexionSQL.Close();
                return ex.ToString();
            }
        }





        /*
         * MÉTODOS INSERT MÉTODOS INSERT MÉTODOS INSERT MÉTODOS INSERT MÉTODOS INSERT MÉTODOS INSERT MÉTODOS INSERT
         */




        internal bool insertPlayer(string[] playerData)
        {
            int nuevoId = 1; 

            string consultaId = "SELECT MAX(id) FROM player";

            SqlCommand comandoId = new SqlCommand(consultaId, miConexionSQL);

            try
            {
                miConexionSQL.Open();
                object resultado = comandoId.ExecuteScalar();
                if (resultado != DBNull.Value)
                {
                    nuevoId = Convert.ToInt32(resultado) + 1; 
                }
                miConexionSQL.Close();
            }
            catch (Exception ex)
            {
                miConexionSQL.Close();
                MessageBox.Show("Error al obtener el último ID: " + ex.Message);
                return false;
            }

            string consulta = "INSERT INTO player (id, firstName, lastName, team, position, dateOfBirth, height, weight, jerseyNumber, age) " +
                              "VALUES (@idPlayer, @namePlayer, @lastName, @team, @position, @birthDate, @height, @weight, @jerseyNumber, @age)";

            SqlCommand comandoSQL = new SqlCommand(consulta, miConexionSQL);

            comandoSQL.Parameters.AddWithValue("@idPlayer", nuevoId);
            comandoSQL.Parameters.AddWithValue("@namePlayer", playerData[0]);
            comandoSQL.Parameters.AddWithValue("@lastName", playerData[1]);
            comandoSQL.Parameters.AddWithValue("@team", playerData[2]);
            comandoSQL.Parameters.AddWithValue("@position", playerData[3]);
            comandoSQL.Parameters.AddWithValue("@birthDate", playerData[4]);
            comandoSQL.Parameters.AddWithValue("@height", playerData[5]);
            comandoSQL.Parameters.AddWithValue("@weight", playerData[6]);
            comandoSQL.Parameters.AddWithValue("@jerseyNumber", playerData[7]);
            comandoSQL.Parameters.AddWithValue("@age", playerData[8]);

            try
            {
                miConexionSQL.Open();
                comandoSQL.ExecuteNonQuery();
                miConexionSQL.Close();
            }
            catch (Exception ex)
            {
                miConexionSQL.Close();
                MessageBox.Show("Error al insertar: " + ex.Message);
                return false;
            }

            return true;
        }


        internal  bool insertTeam(string[] teamData)
        {
            int nuevoId = 1;

            string consultaId = "SELECT MAX(id) FROM team";

            SqlCommand comandoId = new SqlCommand(consultaId, miConexionSQL);

            try
            {
                miConexionSQL.Open();
                object resultado = comandoId.ExecuteScalar();
                if (resultado != DBNull.Value)
                {
                    nuevoId = Convert.ToInt32(resultado) + 1;
                }
                miConexionSQL.Close();
            }
            catch (Exception ex)
            {
                miConexionSQL.Close();
                return false;
            }

            string consulta = "INSERT INTO team (id, name)";

            SqlCommand comandoSQL = new SqlCommand(consulta, miConexionSQL);

            comandoSQL.Parameters.AddWithValue("@idTeam", nuevoId);
            comandoSQL.Parameters.AddWithValue("@nameTeam", teamData[0]);

            try
            {
                miConexionSQL.Open();
                comandoSQL.ExecuteNonQuery();
                miConexionSQL.Close();
            }
            catch (Exception ex)
            {
                miConexionSQL.Close();
                return false;
            }

            return true;


        }






        /*
         * MÉTODOS DELETE MÉTODOS DELETE MÉTODOS DELETE MÉTODOS DELETE MÉTODOS DELETE MÉTODOS DELETE MÉTODOS DELETE
         */


        internal bool deletePlayer(string idPlayer)
        {
            string consulta = "DELETE FROM player WHERE id = @idPlayer";

            SqlCommand comandoSQL = new SqlCommand(consulta, miConexionSQL);

            comandoSQL.Parameters.AddWithValue("@idPlayer", idPlayer);
            try
            {
                miConexionSQL.Open();
                comandoSQL.ExecuteNonQuery();
                miConexionSQL.Close();
            }
            catch (Exception ex)
            {
                miConexionSQL.Close();
                return false;
            }

            return true;
        }


       

    }
}
